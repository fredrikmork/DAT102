package no.hib.dat102.adt;
public interface ParForhold<T>{
     public void bytte();
   	 public T maks();
   
}


